package cn.kgc.personnel.common.pojo;

public class Department {
    /*
     部门id
     */
    private Integer departmentId;
    /*
    部门名称
     */
    private String departmentName;
    /*
    经理
     */
    private Integer manager;
    /*
    办公地点
     */
    private Integer locationId;

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Integer getManager() {
        return manager;
    }

    public void setManager(Integer manager) {
        this.manager = manager;
    }

    public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

}
