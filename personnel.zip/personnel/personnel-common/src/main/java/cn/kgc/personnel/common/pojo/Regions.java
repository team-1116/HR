package cn.kgc.personnel.common.pojo;

/**
 * @program: personnel
 * @ClassName Regions
 * @description:
 * @author: 熊盛涛
 * @create: 2020-11-17 19:00
 * @Version 1.0
 **/
/*
    地区表
 */
public class Regions {
    /*
    地区表的主键id
     */
    private  Integer regionId;

    /*
        地区名称
     */
    private  String regionName;
}
