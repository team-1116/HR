package cn.kgc.hr.service.service;

public interface ApplyService {
    int updateApplyByNumberId(Integer numberId);
}
