package cn.kgc.hr.service.service.impl;

import cn.kgc.hr.service.mapper.RecordMapper;
import cn.kgc.hr.service.service.RecordService;
import cn.kgc.personnel.common.pojo.Record;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

@Service
public class RecordServiceImpl implements RecordService {
    @Resource
    private RecordMapper recordMapper;

    @Override
    public int insertRecord(Record record) {
        return recordMapper.insertRecord(record);
    }

}
