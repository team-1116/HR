package cn.kgc.hr.service.mapper;

import cn.kgc.personnel.common.pojo.Jobs;
import org.apache.ibatis.annotations.Param;



public interface JobsMapper {
    //查询
    Jobs getJobsByJobId(@Param("{jobId}") String jobId);
    //添加
    int addJobs(Jobs jobs);
    //修改
    int updateJobsByJobId(@Param("{jobId}") String jobId);
}
