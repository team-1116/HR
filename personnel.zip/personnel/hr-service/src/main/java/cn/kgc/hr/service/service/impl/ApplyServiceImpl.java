package cn.kgc.hr.service.service.impl;

import cn.kgc.hr.service.mapper.ApplyMapper;
import cn.kgc.hr.service.service.ApplyService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class ApplyServiceImpl implements ApplyService {
    @Resource
    private ApplyMapper applyMapper;
    //修改
    @Override
    public int updateApplyByNumberId(Integer numberId) {
        return  applyMapper.updateApplyByNumberId(numberId);
    }
}
