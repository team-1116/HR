package cn.kgc.hr.service.service;

import cn.kgc.personnel.common.pojo.Record;

public interface RecordService {
    //添加
    int insertRecord(Record record);
}
