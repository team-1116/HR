package cn.kgc.hr.service.mapper;

import cn.kgc.personnel.common.pojo.Record;

public interface RecordMapper {
    //添加
    int insertRecord(Record record);
}
