package cn.kgc.hr.service.service;

import cn.kgc.personnel.common.pojo.Department;


public interface DepartmentService {
    //查询
    Department getDepartmentByDepartmentId(Integer departmentId);
    //添加
    int  intDepartment(Department department);
    //修改
    int updateDepartmentBydepartmentId(Department department);

}
