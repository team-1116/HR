package cn.kgc.hr.service.service;

import cn.kgc.personnel.common.pojo.Employees;

public interface EmployeesService {
    //查询
    Employees getEmployeesByEmployeesId(Integer  employeesID);
    //添加
    int insertEmpyees(Employees employees);
    //修改
    int updateEmpyeesByEmployeesId(Employees employees);
    //删除
    int delectEmpyess(Integer employeesID);
}
