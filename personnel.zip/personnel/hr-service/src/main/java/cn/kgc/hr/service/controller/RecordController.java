package cn.kgc.hr.service.controller;

import cn.kgc.hr.service.service.RecordService;
import cn.kgc.personnel.common.pojo.Employees;
import cn.kgc.personnel.common.pojo.Record;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class RecordController {
    @Resource
    private RecordService recordService;
    //添加
    @PostMapping("/record")
    public int insertRecord(@RequestBody Record record) {
        return recordService.insertRecord(record);
    }
}
