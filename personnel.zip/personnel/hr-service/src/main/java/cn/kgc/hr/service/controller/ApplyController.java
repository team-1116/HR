package cn.kgc.hr.service.controller;

import cn.kgc.hr.service.service.ApplyService;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class ApplyController {
    @Resource
    private ApplyService applyService;
    @PutMapping("/Apply/{numberId}")
    public int updateApplyByNumberId(@PathVariable(value = "numberId")Integer numberId){
        return  applyService.updateApplyByNumberId(numberId);
    }
}
