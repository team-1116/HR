package cn.kgc.hr.service.service;

import cn.kgc.personnel.common.pojo.Jobs;
import org.apache.ibatis.annotations.Param;



public interface JobsService {
    //查询
    Jobs getJobsByJobId(String jobId);
    //添加
    int addJobs(Jobs jobs);
    //修改
    int updateJobsByJobId(String jobId);
}
