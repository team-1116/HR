package cn.kgc.hr.service.controller;

import cn.kgc.hr.service.service.JobsService;
import cn.kgc.personnel.common.pojo.Jobs;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController

public class JobsController {
    @Resource
    private JobsService jobsService;
    //查询
    @GetMapping("/Jobs/{jobId}")
    public Jobs getJobsByJobId(@PathVariable(value = "jobId")String jobId){
        return  jobsService.getJobsByJobId(jobId);
    }
    //添加
    @PostMapping("/Jobs")
    public int addJobs (@RequestBody Jobs jobs){
        return jobsService.addJobs(jobs);
    }
    //修改
    @PutMapping("/Jobs/{jobId}")
    public int updateJobsByJobId(@PathVariable(value = "jobId")String jobId){
        return  jobsService.updateJobsByJobId(jobId);
    }
}
