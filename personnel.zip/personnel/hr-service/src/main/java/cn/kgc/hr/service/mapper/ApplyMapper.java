package cn.kgc.hr.service.mapper;



public interface ApplyMapper {
    //修改
  int updateApplyByNumberId( Integer numberId);
}
