package cn.kgc.hr.service.service.impl;

import cn.kgc.hr.service.mapper.EmployeesMapper;
import cn.kgc.hr.service.service.EmployeesService;
import cn.kgc.personnel.common.pojo.Employees;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class EmployeesServiceImpl implements EmployeesService {
    @Resource
    private EmployeesMapper employeesMapper;
    //查询
    @Override
    public Employees getEmployeesByEmployeesId(Integer employeesID) {
        return  employeesMapper.getEmployeesByEmployeesId(employeesID);
    }
    //添加
    @Override
    public int insertEmpyees(Employees employees) {
        return employeesMapper.insertEmpyees(employees);
    }
    //修改
    @Override
    public int updateEmpyeesByEmployeesId(Employees employees) {
        return employeesMapper.updateEmpyeesByEmployeesId(employees);
    }
    //删除
    @Override
    public int delectEmpyess(Integer employeesID) {
        return  employeesMapper.delectEmpyess(employeesID);
    }


}
