package cn.kgc.hr.service.mapper;

import cn.kgc.personnel.common.pojo.Employees;
import org.apache.ibatis.annotations.Param;


public interface EmployeesMapper {
    //查询
    Employees getEmployeesByEmployeesId(@Param("employeesID") Integer employeesID);
    //添加
    int insertEmpyees(Employees employees);
    //修改
    int updateEmpyeesByEmployeesId(Employees employees);
    //删除
    int delectEmpyess(@Param("{employeesID}") Integer employeesID);
}
