package cn.kgc.hr.service.controller;

import cn.kgc.hr.service.service.EmployeesService;
import cn.kgc.personnel.common.pojo.Employees;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
public class EmployeesController {
    @Resource
    private EmployeesService employeesService;
    //查询
    @GetMapping("/employees/{employeesID}" )
    public Employees getEmployees(@PathVariable(value = "employeesID")Integer employeesID){
        return  employeesService.getEmployeesByEmployeesId(employeesID);
    }
    //添加
    @PostMapping("/employees")
    public int insertEmpyees(@RequestBody Employees employees){
        return  employeesService.insertEmpyees(employees);
    }
    //删除
    @DeleteMapping("/employees/{employeesID}")
    public int delectEmpyess(@PathVariable(value = "employeesID")Integer employeesID){
        return  employeesService.delectEmpyess(employeesID);
    }
    //修改
    @PutMapping("/employees/{employeesID}")
    public int updateEmpyeesByEmployeesId(@PathVariable(value = "employeesID")int employeesID, Employees employees){
        return  employeesService.updateEmpyeesByEmployeesId(employees);
    }


}
