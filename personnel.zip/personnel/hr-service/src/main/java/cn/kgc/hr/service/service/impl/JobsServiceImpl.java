package cn.kgc.hr.service.service.impl;

import cn.kgc.hr.service.mapper.JobsMapper;
import cn.kgc.hr.service.service.JobsService;
import cn.kgc.personnel.common.pojo.Jobs;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class JobsServiceImpl implements JobsService {
    @Resource
    private JobsMapper jobsMapper;
    //查询
    @Override
    public Jobs getJobsByJobId(String jobId) {
        return  jobsMapper.getJobsByJobId(jobId);
    }
    //添加
    @Override
    public int addJobs(Jobs jobs) {
        return jobsMapper.addJobs(jobs);
    }
    //修改
    @Override
    public int updateJobsByJobId(String jobId) {
        return jobsMapper.updateJobsByJobId(jobId);
    }


}
