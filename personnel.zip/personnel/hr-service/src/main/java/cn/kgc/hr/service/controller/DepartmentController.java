package cn.kgc.hr.service.controller;

import cn.kgc.hr.service.service.DepartmentService;
import cn.kgc.personnel.common.pojo.Department;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
public class DepartmentController {
    @Resource
    private DepartmentService departmentService;
    //查询
    @GetMapping("/Department/{departmentId}")
    public Department getDepartmentByDepartmentId(@PathVariable(value = "departmentId")Integer departmentId){
        return departmentService.getDepartmentByDepartmentId(departmentId);
    }
    //添加
    @PostMapping("/Department")
    public int intDepartment(@RequestBody Department department){
        return  departmentService.intDepartment(department);
    }
    //修改
    @PutMapping("/Department/{departmentId}")
    public int updateDepartmentBydepartmentId(@PathVariable(value = "departmentId") Department department){
        return departmentService.updateDepartmentBydepartmentId(department);
    }

}
